#!/bin/bash
mkdir shellScripting
touch distributed_systems.txt



echo "compare and contrast the architectural design of WinXP and Unix in terms of :
General issues
Layering and their functions
Handling of multiple tasks, multiuser applications, multiprocessing


Stability of and security of processes in memory ">distributed_system.txt


pwd

mkdir cmd
cd cmd

cd ..
