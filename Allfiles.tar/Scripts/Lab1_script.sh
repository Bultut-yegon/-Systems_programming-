#!/bin/bash
mkdir Lab1_Dir

cd Lab1_Dir

touch textfile.txt

echo 'Hello World'>textfile.txt

cat textfile.txt

pwd

ls
