#include <stdio.h>
int main(){
int arrays[5]={23,33,43,12,90};
return 0; 
}
