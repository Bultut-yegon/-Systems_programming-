#include <stdio.h>
int main(){
    unsigned char d,w;
    d =17;
    w=22;
    w=w&d;
    printf("%d\n",w);
    return 0;
}