#include <stdio.h>
int main(){
float num;// initializing variable
printf("Enter a floating-point number: ");
scanf("%f", &num);//reading input
printf("You entered: %.2f\n", num);
return 0;//return statement
} 








