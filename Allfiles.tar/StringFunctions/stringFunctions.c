#include<stdio.h>

#include<string.h>
void main(){
char dest[100]="Gen Z generation";



char src[100]="is always amazing";

//combining the two strings using strcat() method in c


strcat(dest,src);




printf("%s",&dest);

}


